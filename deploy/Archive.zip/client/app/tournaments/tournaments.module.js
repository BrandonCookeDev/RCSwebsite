angular.module('RCSapp.tournaments', []);
