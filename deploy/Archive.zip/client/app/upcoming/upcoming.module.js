angular.module('RCSapp.upcoming', ['ui.bootstrap']);
