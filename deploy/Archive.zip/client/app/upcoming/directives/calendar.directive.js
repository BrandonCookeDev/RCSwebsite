angular.module('RCSapp.upcoming')
    .directive('calendarDirective', [function(){
        return{
            templateUrl: 'app/upcoming/views/calendar.html'
        }
    }]);