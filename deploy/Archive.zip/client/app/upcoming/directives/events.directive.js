angular.module('RCSapp.upcoming')
    .directive('eventsDirective', [function(){
        return{
            templateUrl: 'app/upcoming/views/events.html'
        }
    }]);