angular.module('RCSapp.upcoming')
    .directive('upcomingpillsDirective', [function(){
        return{
            templateUrl: 'app/upcoming/views/upcoming_pills.html'
        }
    }]);