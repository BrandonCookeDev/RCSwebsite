angular.module('RCSapp.common')
    .directive('rcsAccordian', [function(){
        return {
            templateUrl: 'app/common/accordian/views/RCSaccordian.html'
        }
    }]);