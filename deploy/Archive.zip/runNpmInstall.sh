npm run-script installRoot
npm run-script installClient
npm run-script installAdminClient