angular.module('AdminPortalApp.home')
    .controller('HomeCtrl', function($scope){


    });
