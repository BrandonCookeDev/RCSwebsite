mongorestore --collection team --db RCSwebsite dump/RCSwebsite/team.bson
mongorestore --collection contact --db RCSwebsite dump/RCSwebsite/contact.bson
mongorestore --collection tournaments --db RCSwebsite dump/RCSwebsite/tournaments.bson
mongorestore --collection users --db RCSwebsite dump/RCSwebsite/users.bson
mongorestore --collection events --db RCSwebsite dump/RCSwebsite/events.bson
