mongodump --db RCSwebsite --collection team
mongodump --db RCSwebsite --collection contact
mongodump --db RCSwebsite --collection tournaments
mongodump --db RCSwebsite --collection users
mongodump --db RCSwebsite --collection events
